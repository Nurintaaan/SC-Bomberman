import java.io.*;
import java.util.*;

/**
* A simple AI implementation
*
* @author Stephen Jaya Gunawan
* @npm 1506731492
* @version 12-03-2017 12:28 AM
*/
public class Bombadabum{
	public static String botName = "Bombadabum";

	public static void main(String[] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Bombadabum bk = new Bombadabum();	
		BoardState state = new BoardState();
		BombadabumAI ai = new BombadabumAI();
		//while(true)
		while(true){
			state.parseBoard(br);
			ai.setCurrentState(state);
			ai.makeMove();
		}
	}

	static class Tile{

		private final BoardState bs;
		private int x, y, fuse, groupByNumber, bombRange;
		private boolean onFire, bomb, containPowerUp, containBombUp, isGrouped;
		private Map<Integer, Player> containPlayers;
		public char type;

		static final char CLEAR = '.';
		static final char DESTRUCTIBLE = 'X';
		static final char INDESCTRUCTIBLE = '#';

		public Tile(BoardState bs, int x, int y, String content){
			this.bs = bs;
			this.x = x;
			this.y = y;
			this.containPlayers = new TreeMap<Integer, Player>();
			
			onFire = false;
			bomb = false;
			groupByNumber = 0;
			isGrouped = false;
			fuse = -1;
			type = 'N'; // null
			checkContent(content);
		}

		public String toString(){
			return "Tile with type " + this.type;
		}

		public void checkContent(String content){

			String[] tileContent = content.trim().split(";");
			
			for(int i = 0; i < tileContent.length; i++){
				if(tileContent[i].length() > 0){
					switch(tileContent[i].charAt(0)){
						case 'F':
							onFire = true;
							this.type = INDESCTRUCTIBLE;
							break;
						case 'B':
							bomb = true;
							bombRange = tileContent[i].charAt(1);
							fuse = tileContent[i].charAt(2);
							this.type = INDESCTRUCTIBLE;
							break;
						case 'X':
							this.type = DESTRUCTIBLE;
							if(tileContent[i].charAt(1) == 'B'){
								containBombUp = true;
							}else if(tileContent[i].charAt(1) == 'P'){
								containPowerUp = true;
							}
							break;
						case '#':
							this.type = INDESCTRUCTIBLE;
							break;
						case '+':
							if(tileContent[i].charAt(1) == 'B'){
								containBombUp = true; 
							}else{
								containPowerUp = true;
							}
							if(type == 'N'){
								this.type = Tile.CLEAR;
							}
							break;
						default:
							for(Map.Entry<String, Player> map : bs.players.entrySet()){
								Player player = map.getValue();
								if(player.index == Integer.parseInt(tileContent[i])){
									this.containPlayers.put(player.index, player);
									player.x = this.x;
									player.y = this.y;
								}
							}
							if(type == 'N'){
								this.type = Tile.CLEAR;
							}
							break;
					}
				}else{
					this.type = CLEAR;
				}
			}
		}
	}

	static class Player{

		private static BoardState bs;
		private int index;
		private int x;
		private int y;

		private String id;
		private int bombUsed;
		private int maxBomb;
		private int bombRange;
		private String status;
		private long score;

		public Player(BoardState st, int index, String id, String bombCount, String bombRange, String status, long score){
			this.id = id;
			this.index = index;
			this.x = -1;
			this.y = -1;
			// BombCount
			String[] splitBombCount = bombCount.split(":")[1].split("/");
			this.bombUsed = Integer.parseInt(splitBombCount[0]);
			this.maxBomb = Integer.parseInt(splitBombCount[1]);
			// BombRange
			this.bombRange = Integer.parseInt(bombRange.split(":")[1]);
			this.status = status;
			this.score = score;
		} 
	}


	static class BoardState{
	
		private int turn, width, height;
		Map<String, Player> players;
		ArrayList<Tile> scoreTiles;
		Tile[][] map;

		public BoardState(){
			players = new TreeMap<String, Player>();
			scoreTiles = new ArrayList<Tile>();
		}

		public void parseBoard(BufferedReader br) throws IOException{
			// TURN
			String[] splitline = br.readLine().split(" ");
			if(!splitline[0].equals("TURN")){
				throw new IOException("Expected TURN, got " + splitline[0]);				
			}
			turn = Integer.parseInt(splitline[1]);
			
			// PLAYERS
			splitline = br.readLine().split(" ");
			if(!splitline[0].equals("PLAYER")){
				throw new IOException("Expected PLAYER, got " + splitline[0]);				
			}
			int numOfPlayers = Integer.parseInt(splitline[1]);
			for(int i = 0; i < numOfPlayers; i++){
				splitline = br.readLine().split(" ");
				players.put(splitline[1], new Player(this, i, splitline[1], splitline[2], splitline[3], splitline[4], Long.parseLong(splitline[5])));
			}

			// BOARD
			splitline = br.readLine().split(" ");
			if(!splitline[0].equals("BOARD")){
				throw new IOException("Expected BOARD, got " + splitline[0]);				
			}
			height = Integer.parseInt(splitline[1]);
			width = Integer.parseInt(splitline[2]);
			map = new Tile[width][height];
			for(int i = 0; i < height; i++){
				
				splitline = br.readLine().split("\\]\\[");
				for(int j = 0; j < width; j++){
					String tileContent = "";
					if(j == 0){
						tileContent = splitline[j].substring(1).trim();
					}else if(j == width-1){
						tileContent = splitline[j].substring(0, splitline[j].length()-1).trim();
					}else{	
						tileContent = splitline[j].trim();
					}
					map[j][i] = new Tile(this, j, i, tileContent);
					if(map[j][i].type == Tile.DESTRUCTIBLE && !map[j][i].bomb){
						scoreTiles.add(map[j][i]);
					}
				}
			}

			// END
			splitline = br.readLine().split(" ");
			if(!splitline[0].equals("END")){	
				throw new IOException("Expected END, got " + splitline[0]);				
			}
		}

		public void getTilesinDirection(int x, int y, int xdir, int ydir, int range, List<Tile> tiles){
			for(int i = 1; i <= range; i++){
				int newX = x + (i * xdir);
				int newY = y + (i * ydir);
				if(newX < 0 || newX >= width || newY < 0 || newY >= height) break;
				Tile tile = map[newX][newY];
				if(tile.type == Tile.DESTRUCTIBLE || tile.type == Tile.CLEAR) tiles.add(tile);
			}
		} 

		public ArrayList<Tile> getTilesInRange(int x, int y, int bombRange){
			ArrayList<Tile> tiles = new ArrayList<Tile>();
			tiles.add(map[x][y]);
			
			getTilesinDirection(x, y, 1, 0, bombRange, tiles);
			getTilesinDirection(x, y, -1, 0, bombRange, tiles);
			getTilesinDirection(x, y, 0, 1, bombRange, tiles);
			getTilesinDirection(x, y, 0, -1, bombRange, tiles);		

			return tiles;
		}

		public ArrayList<Tile> getClearTiles(int x, int y){
			ArrayList<Tile> tiles = new ArrayList<Tile>();
			if(map[x][y].type == Tile.CLEAR){
				tiles.add(map[x][y]);
			}

			return tiles;
		}


	}

	static class BombadabumAI{

		private final ArrayList<String> options;
		private Player bot;
		private LinkedList<String> moves;
		private BoardState bs;
		private EnemyDistanceComparator edc;
		private PowerUpDistanceComparator pdc;

		public BombadabumAI(){
			this.moves = new LinkedList<String>();
			options = new ArrayList<String>();
			options.add(">> MOVE UP");
			options.add(">> MOVE RIGHT");
			options.add(">> MOVE DOWN");
			options.add(">> MOVE LEFT");
		}

		public void setCurrentState(BoardState bs){
			this.bs = bs;
			this.bot = bs.players.get(Bombadabum.botName);
			this.edc = new EnemyDistanceComparator(bs);
			this.pdc = new PowerUpDistanceComparator(bs);
			generateAdjacentTiles();
		}

		public void updateTileGrouping(int from, int to){
			for(int x = 0; x < bs.width; x++){
				for(int y = 0; y < bs.height; y++){
					if(bs.map[x][y].groupByNumber == from){
						bs.map[x][y].groupByNumber = to;
					}
				}
			}
		}

		public void generateAdjacentTiles(){
			int group = 0, new_group = 0;
			boolean incGroup = true;

			// get adjacent clear tiles with an unique number
			// for quick lookup at accessible tiles by bot
			for(int x = 0; x < bs.width; x++){
				for(int y = 0;y < bs.height; y++){
					Tile tile = bs.map[x][y];
					if(tile.type != Tile.CLEAR){
						incGroup = true;
						continue;
					}
					if(incGroup){
						group = ++new_group;
						incGroup = false;
					}
					
					tile.groupByNumber = group;

					if(x > 0){
						int upperTileGroup = bs.map[x-1][y].groupByNumber;
						// if upper group is a CLEAR tile
						if(upperTileGroup == 0){
							continue;
						}
						// else, its adjacent to this tile's group, update the groupNumber
						int maxGroup = Math.max(upperTileGroup, tile.groupByNumber);
						int minGroup = Math.min(upperTileGroup, tile.groupByNumber);

						updateTileGrouping(maxGroup, minGroup);
						group = minGroup;
					}
				}
				incGroup = true;
			}
		}

		public ArrayList<Tile> getAccessibleTiles(int from){
			ArrayList<Tile> tiles = new ArrayList<Tile>();
			
			Tile tile;
			for(int x = 0; x < bs.width; x++){
				for(int y = 0; y < bs.height; y++){
					tile = bs.map[x][y];
					if(tile.groupByNumber == from){
						tiles.add(tile);
					}
				}
			}
			return tiles;
		}

		public boolean isEnemyInRange(){
			ArrayList<Tile> tilesInRange = bs.getTilesInRange(bot.x, bot.y, bot.bombRange);
			for(Tile tile : tilesInRange){
				if(tile.containPlayers.size() > 0 && tile.containPlayers.get(bot.index) == null){
					return true;
				}
			}
			return false;
		}

		public int[] positionAfterMove(int x, int y, String move){
			int posx = x, posy = y;
			switch(move){
				case ">> MOVE DOWN":
					posy = y+1;
					break;
				case ">> MOVE RIGHT":
					posx = x+1;
					break;
				case ">> MOVE UP":
					posy = y-1;
					break;
				case ">> MOVE LEFT":
					posx = x-1;
					break;
			}

			posx = Math.max(0, Math.min(posx, bs.width-1));
			posy = Math.max(0, Math.min(posy, bs.height-1));

			if(bs.map[posx][posy].type == Tile.CLEAR){
				int[] pos = {posx, posy};
				return pos;
			}else{
				int[] pos = {x,y};
				return pos;
			}
		}

		public boolean isMoveSafe(String move){
			int[] newPosition = positionAfterMove(bot.x, bot.y, move);
			Tile tile = bs.map[newPosition[0]][newPosition[1]];
			//System.out.println(bs.getTilesInRange(newPosition[0], newPosition[1], 1).size());
			if(tile.type == Tile.CLEAR){
				return true;
			}
			return false;
		}

		public boolean canPlaceBombAndEscape(LinkedList<String> moves){
			if(bot.bombUsed > 0 && isMoveSafe(">> DROP BOMB")){
				ArrayList<Tile> bombRange = bs.getTilesInRange(bot.x, bot.y, bot.bombRange);
				ArrayList<Tile> moveableTiles = getAccessibleTiles(bs.map[bot.x][bot.y].groupByNumber);
				boolean safe = false, goodBombPlace = false;

				Collections.sort(moveableTiles, edc);
				// System.out.println("Moveable Tiles");
				// for(Tile t : moveableTiles){
				// 	System.out.println(t.x + " " + t.y + " Tile Group : "+  t.groupByNumber);
				// }
				for(Tile t: bombRange){
					//System.out.println("Bomb tiles : " + t.x + " " + t.y );
					if(!goodBombPlace && t.type == Tile.DESTRUCTIBLE){
						goodBombPlace  = true;
					}
				}
				if(isEnemyInRange()) goodBombPlace = true;
				if(!goodBombPlace) return false;

				for (Tile t : moveableTiles) {
					if(!safe && !bombRange.contains(t) && getRouteToTile(t, moves)){
						safe = true;
						//System.out.println("Can escape by going to " + t.x + " " + t.y);
					}
				}

				return safe;
			}

			return false;
		}

		public boolean canFindNearestBonus(LinkedList<String> moves){
			if(bot.bombUsed > 0){
				ArrayList<Tile> moveableTiles = getAccessibleTiles(bs.map[bot.x][bot.y].groupByNumber);
				boolean safe = false;
				for(Tile t : moveableTiles){
					System.out.println("Route " + t.x + " " + t.y);
				}
				Collections.sort(moveableTiles, pdc);
				for (Tile t : moveableTiles) {
					System.out.println("Route " + t.x + " " + t.y);
					if(!safe && getRouteToTile(t, moves)){
						System.out.println("Get route to " + t.x + " " + t.y);
						safe = true;
					}
				}

				return safe;
			}

			return false;
		}

		public void makeMove(){					
			String move = moves.poll();
			if(move == null || !isMoveSafe(move)){
				moves.clear();
				if(canPlaceBombAndEscape(moves)){
					System.out.println("BOMB TIME :D");
					move = ">> DROP BOMB";
				}else if(canFindNearestBonus(moves)){
					System.out.println("GO GET SCORES !");
					move = moves.poll();
				}else{
					System.out.println("CANT PLACE BOMB, MOVE !");
					System.out.println("Current position : " + bot.x + " " + bot.y);

					//move randomly
					for(int i = 0; i < options.size(); i++){
						String moveCandidate = options.get(i);
						int[] newPosition = positionAfterMove(bot.x, bot.y, moveCandidate);
						if(newPosition[0] == bot.x && newPosition[1] == bot.y){
							continue;
						}
						if(isMoveSafe(moveCandidate)){
							move = moveCandidate;
							break;	
						}
					}
				}
			}

			if(move == null){
				move = ">> STAY";
			}

			System.out.println(move);
		}

		public void BFSCheck(Queue<BFSTile> tileQueue, BFSTile previousTile, ArrayList<Tile> accessTiles, boolean[][] visited, String direction){
			int[] position = positionAfterMove(previousTile.currentTile.x, previousTile.currentTile.y , direction);
			
			//System.out.println("Checking position with direction " + direction + ", if its BFS-able");
			
			if(!visited[position[0]][position[1]]){
				Tile tile = bs.map[position[0]][position[1]];
				visited[position[0]][position[1]] = true;
				if(accessTiles.contains(tile)){
					//System.out.println("BFS-able, Added to the Queue " + tile.x + " " + tile.y + " from " + previousTile.currentTile.x + " " + previousTile.currentTile.y);
					tileQueue.add(new BFSTile(tile, previousTile, direction));
				}
			}
		}

		public boolean getRouteToTile(Tile to, LinkedList<String> route){
			// if not adjacent, we cannot go to that route
			if(bs.map[bot.x][bot.y].groupByNumber != to.groupByNumber) return false;

			boolean[][] visited = new boolean[bs.width][bs.height];
			ArrayList<Tile> accessTiles = getAccessibleTiles(bs.map[bot.x][bot.y].groupByNumber);
			Queue<BFSTile> tileQueue = new LinkedList<BFSTile>();
			tileQueue.add(new BFSTile(bs.map[bot.x][bot.y], null, null));
			visited[bot.x][bot.y] = true;

			//System.out.println("Finding route to " + to.x + " " + to.y);
			
			while(true){
				BFSTile btile = tileQueue.peek();
				if(btile == null){
					return false;
				}
				if(btile.currentTile.x == to.x && btile.currentTile.y == to.y){
				//	System.out.println("Reached position " + btile.currentTile.x +" "+ btile.currentTile.y);
					break;
				}
  				
  				//System.out.println("Checking tile after " + btile.direction + ", position " + btile.currentTile.x + " " + btile.currentTile.y);
				if(btile.currentTile.y > 0) BFSCheck(tileQueue, btile, accessTiles, visited, ">> MOVE UP");
				if(btile.currentTile.y < bs.height-1) BFSCheck(tileQueue, btile, accessTiles, visited, ">> MOVE DOWN");
				if(btile.currentTile.x > 0) BFSCheck(tileQueue, btile, accessTiles, visited, ">> MOVE LEFT");
				if(btile.currentTile.x < bs.width-1) BFSCheck(tileQueue, btile, accessTiles, visited, ">> MOVE RIGHT");
				
				tileQueue.poll();
			}

			for(BFSTile t = tileQueue.poll(); t != null;t = t.prevTile){
				if(t.direction != null){
					route.addFirst(t.direction);
					//System.out.println("DIRECTION " + route.peek());
				}
			}

			return true;

		}

		private class BFSTile{
			private Tile currentTile;
			private BFSTile prevTile;
			private String direction;

			public BFSTile(Tile tile, BFSTile prevTile, String direction){
				this.currentTile = tile;
				this.prevTile = prevTile;
				this.direction = direction;
			}
		}

		private class EnemyDistanceComparator implements Comparator<Tile>{
			Collection<Player> players;
			public EnemyDistanceComparator(BoardState bs){
				this.players = bs.players.values();
			}

			// calculate manhattan distance
			@Override
			public int compare(Tile t1, Tile t2){
				int distance1 = Integer.MAX_VALUE, distance2 = Integer.MAX_VALUE;
				for(Player p : players){
					if(p.id.equals(Bombadabum.botName)) continue;
					distance1 = Math.min(distance1, Math.abs(t1.x - p.x) + Math.abs(t1.y - p.y));
					distance2 = Math.min(distance2, Math.abs(t2.x - p.x) + Math.abs(t2.y - p.y));

				}

				return distance1 - distance2;
			}
		}

		private class PowerUpDistanceComparator implements Comparator<Tile>{

			Collection<Tile> tiles;
			public PowerUpDistanceComparator(BoardState bs){
				this.tiles = bs.scoreTiles;
			}

			@Override
			public int compare(Tile t1, Tile t2){
				int distance1 = Integer.MAX_VALUE, distance2 = Integer.MAX_VALUE;
				for(Tile t : tiles){
					distance1 = Math.min(distance1, Math.abs(t1.x - t.x) + Math.abs(t2.x - t.x));
					distance2 = Math.min(distance2, Math.abs(t2.x - t.x) + Math.abs(t2.x - t.x));
				}

				// if(distance1 > distance2){
				// 	System.out.println("Route to nearest score tile " + t1.x +" "+ t1.y + ", Compared to " + t2.x + " " + t2.y);
				// }else{

				// 	System.out.println("Route to nearest score tile " + t2.x +" "+ t2.y + ", Compared to " + t1.x + " " + t1.y);
				// }
				return distance2 - distance1;
			} 
		}
	}
}

// TURN 1
// PLAYER 2
// P0 Bombadabum Bomb:1/1 Range:1 Alive 0
// P1 ContohAI1 Bomb:1/1 Range:1 Alive 0
// BOARD 2 3
// [     ][  0  ][ XXX ]
// [     ][ XXX ][  1  ]
// END

// TURN 1
// PLAYER 2
// P0 Bombadabum Bomb:0/1 Range:1 Alive 0
// P1 RandomAI1 Bomb:0/1 Range:1 Alive 0
// BOARD 2 5
// [ XXX ][0;B18][     ][ XXX ][1;B18]
// [     ][     ][ XXX ][ ### ][ ### ]






